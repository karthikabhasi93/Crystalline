<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-03 16:50:39 --> Config Class Initialized
INFO - 2020-10-03 16:50:39 --> Hooks Class Initialized
DEBUG - 2020-10-03 16:50:39 --> UTF-8 Support Enabled
INFO - 2020-10-03 16:50:39 --> Utf8 Class Initialized
INFO - 2020-10-03 16:50:39 --> URI Class Initialized
INFO - 2020-10-03 16:50:39 --> Router Class Initialized
INFO - 2020-10-03 16:50:39 --> Output Class Initialized
INFO - 2020-10-03 16:50:39 --> Security Class Initialized
DEBUG - 2020-10-03 16:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-03 16:50:39 --> Input Class Initialized
INFO - 2020-10-03 16:50:39 --> Language Class Initialized
INFO - 2020-10-03 16:50:39 --> Language Class Initialized
INFO - 2020-10-03 16:50:39 --> Config Class Initialized
INFO - 2020-10-03 16:50:39 --> Loader Class Initialized
INFO - 2020-10-03 16:50:39 --> Helper loaded: url_helper
INFO - 2020-10-03 16:50:39 --> Helper loaded: file_helper
INFO - 2020-10-03 16:50:39 --> Database Driver Class Initialized
DEBUG - 2020-10-03 16:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-03 16:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-03 16:50:39 --> Controller Class Initialized
ERROR - 2020-10-03 16:50:39 --> 404 Page Not Found: ../modules/admin/controllers/Admin/a
INFO - 2020-10-03 16:50:42 --> Config Class Initialized
INFO - 2020-10-03 16:50:42 --> Hooks Class Initialized
DEBUG - 2020-10-03 16:50:42 --> UTF-8 Support Enabled
INFO - 2020-10-03 16:50:42 --> Utf8 Class Initialized
INFO - 2020-10-03 16:50:42 --> URI Class Initialized
INFO - 2020-10-03 16:50:42 --> Router Class Initialized
INFO - 2020-10-03 16:50:42 --> Output Class Initialized
INFO - 2020-10-03 16:50:42 --> Security Class Initialized
DEBUG - 2020-10-03 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-03 16:50:42 --> Input Class Initialized
INFO - 2020-10-03 16:50:42 --> Language Class Initialized
INFO - 2020-10-03 16:50:42 --> Language Class Initialized
INFO - 2020-10-03 16:50:42 --> Config Class Initialized
INFO - 2020-10-03 16:50:42 --> Loader Class Initialized
INFO - 2020-10-03 16:50:42 --> Helper loaded: url_helper
INFO - 2020-10-03 16:50:42 --> Helper loaded: file_helper
INFO - 2020-10-03 16:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-03 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-03 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-03 16:50:42 --> Controller Class Initialized
DEBUG - 2020-10-03 16:50:42 --> Admin MX_Controller Initialized
INFO - 2020-10-03 16:50:42 --> Helper loaded: form_helper
INFO - 2020-10-03 16:50:42 --> Form Validation Class Initialized
DEBUG - 2020-10-03 16:50:42 --> Config file loaded: /opt/lampp/htdocs/Crystalline/application/config/grocery_crud.php
INFO - 2020-10-03 16:50:42 --> Model "Grocery_crud_model" initialized
DEBUG - 2020-10-03 16:50:42 --> File loaded: /opt/lampp/htdocs/Crystalline/application/modules/admin/views/home.php
INFO - 2020-10-03 16:50:42 --> Final output sent to browser
DEBUG - 2020-10-03 16:50:42 --> Total execution time: 0.0643
